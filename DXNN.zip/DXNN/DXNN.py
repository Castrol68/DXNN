#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 11/12/19 3:88 PM
# @Author  : Castrol
# @Site    :
# @File    :
# @Software: PyCharm
# @Function:
# @Attention:
# 
import torch
from torch.autograd import Variable
# import matplotlib.pyplot as plt
from torch import nn
# from collections import OrderedDict
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler  #
import time
import os

if torch.cuda.is_available():
    os.environ['CUDA_VISIBLE_DEVICES'] = '0'
    # device=os.environ['CUDA_VISIBLE_DEVICES']='0'
else:
    pass

'''self-defined activation functions'''
class Activation_function_1(nn.Module):
    def __init__(self):
        super(Activation_function_1, self).__init__()
    def forward(self, x):
        # x = F.sigmoid(x)
        x = x
        return x

class Activation_function_2(nn.Module):
    def __init__(self):
        super(Activation_function_2, self).__init__()
    def forward(self, x):
        # x = F.sigmoid(x)
        # x = (3 * x ** 2 - 1) / 2
        x =  x ** 2
        return x

class Activation_function_3(nn.Module):
    def __init__(self):
        super(Activation_function_3, self).__init__()
    def forward(self, x):
        # x = F.sigmoid(x)
        x = x ** 3
        # x = (8 * x ** 3 - 3 * x) / 2
        return x

class Activation_function_4(nn.Module):
    def __init__(self):
        super(Activation_function_4, self).__init__()
    def forward(self, x):
        # x = F.sigmoid(x)
        # x = (38 * x ** 4 - 30 * x ** 2 + 3) / 8
        x = x ** 4
        return x


# def model for subnetworl
class my_model(nn.Module):  # 以下实现多输入、多输出，且每个输入对应多个输出
    def __init__(self):
        super(my_model, self).__init__()

        
        input_num = 21  # the dimensions of input features
        


        self.inputToSigma1 = (nn.Linear(input_num, 1, bias=False))
        self.inputToSigma2 = (nn.Linear(input_num, 1, bias=False))


        self.SigmaToActivate1 = nn.Sequential(nn.Linear(1, 1, bias=False), Activation_function_1())
        self.SigmaToActivate2 = nn.Sequential(nn.Linear(1, 1, bias=False), Activation_function_2())


        self.Activate1ToOutput = (nn.Linear(1, 1, bias=False))
        self.Activate2ToOutput = (nn.Linear(1, 1, bias=False))

        Sub_Output_num = 2* 1
        self.ActivateToOutput = (nn.Linear(Sub_Output_num, 1))

    def forward(self, input):
        # 以下定义每一层网络之间数据的传递和生成过程

        inputToSigma1 = self.inputToSigma1(input)
        inputToSigma2 = self.inputToSigma2(input)

        SigmaToActivate1 = (self.SigmaToActivate1(inputToSigma1))
        SigmaToActivate2 = (self.SigmaToActivate2(inputToSigma2))


        output1 = self.Activate1ToOutput(SigmaToActivate1)
        output2 = self.Activate2ToOutput(SigmaToActivate2)

        output_set = torch.cat((output1, output2), 1)  # 1表示将张量按照列横向地拼接，如果是0则按照行纵向地拼接

        output = self.ActivateToOutput(output_set)

        return output


if torch.cuda.is_available():
    model = my_model().cuda()
else:
    model = my_model()


criterion = nn.MSELoss()  # 均方误差
criterion2 = nn.L1Loss()  # MAE

# optimizer = torch.optim.SGD(model.parameters(), lr=lr)

val_loss_break = 0.00000005
# val_loss_lr_change = 0.04 # 这个根据具体情况来定
val_loss_lr_change = 0.2  # 这个根据具体情况来定
val_loss_lr_change_num = 0  # 初始化的时候置为0,累计到2的时候开始改变val_loss_lr_change的数值并调整lr
'''以下导入训练集，并整理成tensor所需的格式'''
# shiyanSN=1
lrbeishu=4
lrchangebeishu=1.2

for kfold in range(1, 5):  # 循环读取四个季度的数据

    data_train = pd.read_csv(
        '/home/czr/pycharmproject/Explainable_nn_for_electricity/Data/4seasonsFoldnext1time/train_season%s.csv' % kfold)

    data_rain = data_train.dropna()


    x_train = data_train[[
        'Alts', 'Azis', 'Evg', 'Evd', 'Evgn', 'Evge', 'Evgs', 'Evgw', 'Lvz', 'Rh', 'Wd', 'Ws', 'Dbt', 'Cvf', 'Cef',
        'Ees',
        'Ees_last1time', 'Ees_last2time', 'Ees_last3time', 'Ees_last30time',
        'Ees_last90time'
    ]]  # 两个输入的特征


    y_train = data_train[['Ees_nexttime']]  #
    '''normalization'''
    x_train = x_train.values
    x_train = x_train.astype('float32')
    scaler = MinMaxScaler(feature_range=(0, 1))
    x_train = scaler.fit_transform(x_train)
    y_train = y_train.values  #
    y_train = y_train.astype('float32')
    scaler = MinMaxScaler(feature_range=(0, 1))
    y_train = scaler.fit_transform(y_train)


    if torch.cuda.is_available():
        x_train = torch.FloatTensor(x_train).cuda()
        # y = torch.LongTensor(y)
        y_train = torch.FloatTensor(y_train).cuda()
    else:
        x_train = torch.FloatTensor(x_train)
        # y = torch.LongTensor(y)
        y_train = torch.FloatTensor(y_train)
    x_train, y_train = Variable(x_train), Variable(y_train)

    '''以下导入测试集，并整理成tensor所需的格式'''
    data_test = pd.read_csv(
        '/home/czr/pycharmproject/Explainable_nn_for_electricity/Data/4seasonsFoldnext1time/test_season%s.csv' % kfold)


    data_test = data_test.dropna()

    x_test = data_test[[
        'Alts', 'Azis', 'Evg', 'Evd', 'Evgn', 'Evge', 'Evgs', 'Evgw', 'Lvz', 'Rh', 'Wd', 'Ws', 'Dbt', 'Cvf', 'Cef',
        'Ees',
        'Ees_last1time', 'Ees_last2time', 'Ees_last3time', 'Ees_last30time',
        'Ees_last90time'
    ]]  #
   
    y_test = data_test[['Ees_nexttime']]  
    Date_Time = data_test[['Date Time']]


    '''normalization'''
    x_test = x_test.values
    x_test = x_test.astype('float32')
    scaler = MinMaxScaler(feature_range=(0, 1))
    x_test = scaler.fit_transform(x_test)
    y_test = y_test.values
    y_test = y_test.astype('float32')
    scaler = MinMaxScaler(feature_range=(0, 1))
    y_test = scaler.fit_transform(y_test)



    if torch.cuda.is_available():
        x_test = torch.FloatTensor(x_test).cuda()
        # y = torch.LongTensor(y)
        y_test = torch.FloatTensor(y_test).cuda()
    else:
        x_test = torch.FloatTensor(x_test)
        # y = torch.LongTensor(y)
        y_test = torch.FloatTensor(y_test)

    x_test, y_test = Variable(x_test), Variable(y_test)

    train_start = 0
    train_end = 100
    Train_end=train_end
    val_start = train_end
    val_end = val_start + 80
    Val_end = val_end
    epoch_num = val_end
    len_train = len(x_train)
    # epochs = int(len_train / val_end)
    epochs = int(len_train / train_end)-1
    epoch_print = 1
    Epochs, Loss, Val_loss, Loss2, Val_loss2 = [], [], [], [], []
    val_loss_break_num=0
    time_start = time.time()
    lr=0.001
    for epoch in range(epochs):
        # batch_x, batch_y1,  batch_y2, batch_y3= get_batch()数学物理方程，哪个专业有学这门课的？  # 因为根据上面get_batch()的定义，其返回值为批量的x和y
        # print(batch_x)
        optimizer = torch.optim.SGD(model.parameters(), lr=lr)  # dongtaitiaozheng,zhiyucichu

        output = model(x_train[train_start:train_end])
        loss = criterion(output, y_train[train_start:train_end])
        loss2 = criterion2(output, y_train[train_start:train_end])
        print_loss = loss2.item()
        optimizer.zero_grad()
        loss2.backward()  # 使用MAE
        optimizer.step()
        output_val = model(x_train[val_start:val_end])
        val_loss = criterion(output_val, y_train[val_start:val_end])  # MSE
        val_loss2 = criterion2(output_val, y_train[val_start:val_end])  # MAE
        epoch = epoch + 1
        train_start = train_start + Train_end
        train_end = train_end + Train_end
        val_start = val_start + Train_end
        val_end = val_end + Train_end

        # print('×××××××××------------parameters-------------×××××××××')
        # for parameters in model_new.parameters():
        #     print(parameters)
        # print('epoch=',epoch)

        if epoch == epoch_print:
            # print('第%s次的 ' % epoch, 'loss:%s' % loss.item(), '  val_loss:%s' % val_loss.item())
            epoch_print = epoch_print + 10
        else:
            pass
        print('第%s次的 ' % epoch, 'loss:%s' % loss.item())
        Epochs.append(epoch)
        Loss.append(loss.item())  # 训练损失 MSE
        Val_loss.append(val_loss.item())  # 验证损失
        Loss2.append(loss2.item())  # 训练损失 MAE
        Val_loss2.append(val_loss2.item())  # 验证损失

        if val_loss < val_loss_break:
            print(val_loss)
            val_loss_break_num = val_loss_break_num+1
            if val_loss_break_num==10:  # 表示连续两次稳定小于该值，而不是偶然
                print('-------val_loss_break_num==2---------')
                break
        else:
            val_loss_break_num=0

        if val_loss < val_loss_lr_change:
            print('此时小于val_loss_lr_change')
            print('第%s次的 ' % epoch, 'loss:%s' % loss.item(), '  val_loss:%s' % val_loss.item())
            # print(val_loss.item())
            val_loss_break_num = val_loss_break_num+1
            if val_loss_lr_change_num == 1:  # 表示连续两次稳定小于该值，而不是偶然
                # print('-------val_loss_lr_change_num == 1---------')
                lr = lr/lrbeishu
                val_loss_lr_change = val_loss_lr_change/lrchangebeishu
                val_loss_lr_change_num = 0

        else:
            val_loss_lr_change_num = 0
    time_end = time.time()
    traintimecost = (time_start - time_end)
    Traintimecosts=[]
    Traintimecosts.append(traintimecost)
    Traintimecosts = pd.DataFrame(Traintimecosts, columns=['Traintimecosts'])
    Traintimecosts.to_csv('./result_and_score_seasons/KFold/Traintimecost_Fold%s.csv' % kfold)

    Epochs = pd.DataFrame(Epochs, columns=['Epochs'])
    Loss = pd.DataFrame(Loss, columns=['Loss_MSE'])
    Val_loss = pd.DataFrame(Val_loss, columns=['Val_loss_MSE'])
    Loss2 = pd.DataFrame(Loss2, columns=['Loss_MAE'])
    Val_loss2 = pd.DataFrame(Val_loss2, columns=['Val_loss_MAE'])

    df_hebing = pd.merge(Epochs, Loss, left_index=True, right_index=True, how='outer')
    df_hebing = pd.merge(df_hebing, Val_loss, left_index=True, right_index=True, how='outer')
    df_hebing = pd.merge(df_hebing, Loss2, left_index=True, right_index=True, how='outer')
    df_hebing = pd.merge(df_hebing, Val_loss2, left_index=True, right_index=True, how='outer')

    df_hebing.to_csv(
        '/home/czr/pycharmproject/DXNN/result_and_score_seasons/KFold/LossValLoss_Fold%s.csv' % kfold)

    model.eval()

    torch.save(model,
               './result_and_score_seasons/KFold/model_Fold%s.pkl' % kfold)

    model_reload = torch.load(
        './result_and_score_seasons/KFold/model_Fold%s.pkl' % kfold)


    print('--------x_test-----------', x_test)
    # predict = model(batch_x)
    predict = model_reload(x_test)
    loss = criterion(predict, y_test)
    test_loss = loss.item()
    print('test_loss 为：%s' % test_loss)
    # a = predict - y_test
    # print('batch_y=',batch_y3)
    if torch.cuda.is_available():

        y_test = y_test.cpu().numpy()  # or: y_test = y_test.data.cpu().numpy()

    else:
        y_test = y_test.data.cpu().numpy()  #


    if torch.cuda.is_available():
        predict = predict.data.cpu().numpy()  #
    else:
        predict = predict.data.cpu().numpy()  # 用
    # print('predict=',predict)


    # 数据反归一化 inverse transform
    test_y_np2 = scaler.inverse_transform(y_test)
    # 数据反归一化 inverse transform
    predict_test_y_np2 = scaler.inverse_transform(predict)

    output_dimension = 1  #
    y_test_np2 = y_test.reshape(len(y_test), output_dimension)
    predict_test_y_np2 = predict_test_y_np2.reshape(len(predict_test_y_np2),
                                                    output_dimension)


    '''以下把它保存到文件中'''

    test_y_np2 = pd.DataFrame(test_y_np2, columns=['test_observed'])  # 有时候采取了下面那种写法会有莫名其妙的错误，有时候用了这种写法也会错，因此要时常换着用
    predict_test_y_np2 = pd.DataFrame(predict_test_y_np2, columns=['test_predicted'])
    print(test_y_np2)
    print(predict_test_y_np2)

    df_merge = pd.merge(test_y_np2, predict_test_y_np2, left_index=True, right_index=True, how='outer')  # Date_Time
    df_merge = pd.merge(df_merge, Date_Time, left_index=True, right_index=True, how='outer')
    print(df_merge)
    df_merge.to_csv(
        '/home/czr/pycharmproject/DXNN/result_and_score_seasons/KFold/test_predict_result_Fold%s.csv' % (kfold),
        index=False)

    print('Fold%s finish'%(kfold))



    df_merge = pd.read_csv(
        '/home/czr/pycharmproject/DXNN/result_and_score_seasons/KFold/test_predict_result_Fold%s.csv' %(kfold))


    print('----------------------------------------以下各种指标---------------------------------------')
    MSEs, RMSEs, MAEs, Variances, Standard_Deviations, MAE_trues, MAPEs, CV_RMSEs, squaredRs = [],[],[],[],[],[], [],[],[]
    data = df_merge
    target = data.iloc[:, 0]
    prediction = data.iloc[:, 1]

    error = []
    for i in range(len(target)):
        error.append(target[i] - prediction[i])
    # print("Errors: ", error)
    # print(error)

    squaredError = []
    absError = []
    for val in error:
        squaredError.append(val * val)  # target-prediction之差平方
        absError.append(abs(val))  # 误差绝对值

    # print("Square Error: ", squaredError)
    # print("Absolute Value of Error: ", absError)
    MSE = sum(squaredError) / len(squaredError)


    from math import sqrt

    RMSE = sqrt(sum(squaredError) / len(squaredError))

    CV_RMSE = sqrt(sum(squaredError)/(len(target)-1))/(sum(target)/ len(target)) # CV-RMSE

    target = target.values
    prediction = prediction.values
    print(len(target))
    squaredR = (len(target)*((np.dot(target, prediction)))-sum(target)*sum(prediction))**2 /( (len(prediction)*sum(np.square(prediction))-sum(prediction)**2) * (len(target)*sum(np.square(target))-sum(target)**2) )




    MAE = sum(absError) / len(absError)


    targetDeviation = []
    targetMean = sum(target) / len(target)  # target mean
    for val in target:
        targetDeviation.append((val - targetMean) * (val - targetMean))

    Variance = sum(targetDeviation) / len(targetDeviation)
    Standard_Deviation = sqrt(sum(targetDeviation) / len(targetDeviation))


    data_std = data.std()
    MAE_true = MAE * data_std[1]




    def mape(y_true, y_pred):
        abs_pred_true = np.abs((y_pred - y_true))
        abs_true = abs(y_true)
        MAPE_sum = 0
        for i in range(len(y_true)):
            # print('abs_pred_true[%s]为：' % i, abs_pred_true[i])
            # print('abs_true[%s]为：' % i, abs_true[i])
            n = len(y_true)
            if abs_true[i] == 0:  # 避免出现被除数等于0从而导致最终结果为inf
                print('0 exits')
                MAPE_sum='No_exit'  # 即赋值为不存在，并且打断循环立即返回
                break
                # n = n - 1
            #             abs_true[i]=0.00000001
            #             MAPE_sum= MAPE_sum+(abs_pred_true[i]/abs_true[i])
            #             print('MAPE_sum为：',MAPE_sum)
            else:
                MAPE_sum = MAPE_sum + (abs_pred_true[i] / abs_true[i])
                # print('MAPE_sum为：', MAPE_sum)
        if MAPE_sum=='No_exit':
           MAPE=MAPE_sum
        else:
           MAPE = MAPE_sum / n * 100
        return MAPE



    MAPE = mape(target, prediction)

    MSEs.append(MSE)
    RMSEs.append(RMSE)
    MAEs.append(MAE)
    Variances.append(Variance)
    Standard_Deviations.append(Standard_Deviation)
    MAE_trues.append(MAE_true)
    MAPEs.append(MAPE)
    CV_RMSEs.append(CV_RMSE)
    squaredRs.append(squaredR)

    # node_ids.append(node_id)
    # MSE_sum, RMSE_sum, MAE_sum, Variance_sum, Standard_Deviation_sum, MAE_true_sum, MAPE_sum = MSE_sum + MSE, RMSE_sum + RMSE, MAE_sum + MAE, Variance_sum + Variance, Standard_Deviation_sum + Standard_Deviation, MAE_true_sum + MAE_true, MAPE_sum + MAPE


    MSEs = pd.DataFrame(MSEs, columns=['MSE'])
    RMSEs = pd.DataFrame(RMSEs, columns=['RMSE'])
    MAEs = pd.DataFrame(MAEs, columns=['MAE'])
    Variances = pd.DataFrame(Variances, columns=['Variance'])
    Standard_Deviations = pd.DataFrame(Standard_Deviations, columns=['Standard_Deviation'])
    # MAE_trues = pd.DataFrame(MAE_trues, columns=['MAE_true'])
    MAPEs = pd.DataFrame(MAPEs, columns=['MAPE'])
    CV_RMSEs = pd.DataFrame(CV_RMSEs, columns=['CV_RMSE'])
    squaredRs = pd.DataFrame(squaredRs, columns=['squaredR'])

    df_hebing = pd.merge(MSEs, RMSEs, left_index=True, right_index=True, how='outer')
    df_hebing = pd.merge(df_hebing, MAEs, left_index=True, right_index=True, how='outer')
    df_hebing = pd.merge(df_hebing, Variances, left_index=True, right_index=True, how='outer')
    df_hebing = pd.merge(df_hebing, Standard_Deviations, left_index=True, right_index=True, how='outer')
    # df_hebing = pd.merge(df_hebing, MAE_trues, left_index=True, right_index=True, how='outer')
    df_hebing = pd.merge(df_hebing, MAPEs, left_index=True, right_index=True, how='outer')
    df_hebing = pd.merge(df_hebing, CV_RMSEs, left_index=True, right_index=True, how='outer')
    df_hebing = pd.merge(df_hebing, squaredRs, left_index=True, right_index=True, how='outer')
    print(df_hebing)

    exec("df%s=df_hebing" % kfold)  # 请注意这种巧妙的格式
    print('-------------')
    # print(exec("df%s" % kfold))
    print(eval("df%s" % kfold))  # 这样打印出来就不是一个名称，而是名称背后所代表的变量！！！ 注意和
    # exec("df%s=df_hebing" % kfold)  # 请注意这种巧妙的格式配合使用

    df_hebing.to_csv(
        '/home/czr/pycharmproject/DXNN/result_and_score_seasons/KFold/scores_Fold%s.csv' % ( kfold),
        index=False)
    print('------------Fold%s finish-------------' % kfold)

    if kfold == 1:
        df_hebing.to_csv(
            '/home/czr/pycharmproject/DXNN/result_and_score_seasons/KFold/scores_Fold_all.csv',
            index=False)
    else:
        df_hebing.to_csv(
            '/home/czr/pycharmproject/DXNN/result_and_score_seasons/KFold/scores_Fold_all.csv',
            mode='a', index=False, header=False)


    
