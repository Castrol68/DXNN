#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 11/12/19 3:88 PM
# @Author  : Castrol
# @Site    :
# @File    :
# @Software: PyCharm
# @Function:
# @Attention:
# @environment: python3.7, pytorch1.4
import torch
from torch.autograd import Variable
# import matplotlib.pyplot as plt
from torch import nn
# from collections import OrderedDict
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler  #
import time
import os
from math import sqrt

if torch.cuda.is_available():
    os.environ['CUDA_VISIBLE_DEVICES'] = '0'
    # device=os.environ['CUDA_VISIBLE_DEVICES']='0'
else:
    pass

'''self-defined activation functions''' # they could be adjusted according to the actual conditions
class Activation_function_1(nn.Module):
    def __init__(self):
        super(Activation_function_1, self).__init__()
    def forward(self, x):
        # x = F.sigmoid(x)
        x = x
        return x

class Activation_function_2(nn.Module):
    def __init__(self):
        super(Activation_function_2, self).__init__()
    def forward(self, x):
        # x = F.sigmoid(x)
        # x = (3 * x ** 2 - 1) / 2
        x =  x ** 2
        return x

class Activation_function_3(nn.Module):
    def __init__(self):
        super(Activation_function_3, self).__init__()
    def forward(self, x):
        # x = F.sigmoid(x)
        x = x ** 3
        # x = (8 * x ** 3 - 3 * x) / 2
        return x

class Activation_function_4(nn.Module):
    def __init__(self):
        super(Activation_function_4, self).__init__()
    def forward(self, x):
        # x = F.sigmoid(x)
        # x = (38 * x ** 4 - 30 * x ** 2 + 3) / 8
        x = x ** 4
        return x


# model
class my_model(nn.Module):
    def __init__(self):
        super(my_model, self).__init__()

        
        input_num = 21  # the dimensions of input features
        


        self.inputToSigma1 = (nn.Linear(input_num, 1, bias=False))
        self.inputToSigma2 = (nn.Linear(input_num, 1, bias=False))


        self.SigmaToActivate1 = nn.Sequential(nn.Linear(1, 1, bias=False), Activation_function_1())
        self.SigmaToActivate2 = nn.Sequential(nn.Linear(1, 1, bias=False), Activation_function_2())

        self.Activate1ToOutput = (nn.Linear(1, 1, bias=False))
        self.Activate2ToOutput = (nn.Linear(1, 1, bias=False))

        Sub_Output_num = 2* 1
        self.ActivateToOutput = (nn.Linear(Sub_Output_num, 1))

    def forward(self, input):

        inputToSigma1 = self.inputToSigma1(input)
        inputToSigma2 = self.inputToSigma2(input)

        SigmaToActivate1 = (self.SigmaToActivate1(inputToSigma1))
        SigmaToActivate2 = (self.SigmaToActivate2(inputToSigma2))

        output1 = self.Activate1ToOutput(SigmaToActivate1)
        output2 = self.Activate2ToOutput(SigmaToActivate2)

        output_set = torch.cat((output1, output2), 1)  #

        output = self.ActivateToOutput(output_set)

        return output


if torch.cuda.is_available():
    model = my_model().cuda()
else:
    model = my_model()

criterion = nn.MSELoss()  # MSE
criterion2 = nn.L1Loss()  # MAE


lr=0.02    # It can be adjusted according to the actual conditions
val_loss_break = 0.00005  # It can be adjusted according to the actual conditions


for kfold in range(1, 5):  # read in the dataset by 4 files

    data_train = pd.read_csv(
        './Data/4seasonsFoldnext1time/train_fold%s.csv' % kfold) # this is the path of your training set.


    data_rain = data_train.dropna()

    x_train = data_train[[
        'Alts', 'Azis', 'Evg', 'Evd', 'Evgn', 'Evge', 'Evgs', 'Evgw', 'Lvz', 'Rh', 'Wd', 'Ws', 'Dbt', 'Cvf', 'Cef',
        'Ees',
        'Ees_1time', 'Ees_2time', 'Ees_3time', 'Ees_30time',
        'Ees_90time'
    ]]  # these should be replaced by your real input features' names.

    y_train = data_train[['Ees_nexttime']]  # this should be replaced by your real output feature' name.

    '''normalization'''
    x_train = x_train.values
    x_train = x_train.astype('float32')
    scaler = MinMaxScaler(feature_range=(0, 1))
    x_train = scaler.fit_transform(x_train)
    y_train = y_train.values  #
    y_train = y_train.astype('float32')
    scaler = MinMaxScaler(feature_range=(0, 1))
    y_train = scaler.fit_transform(y_train)


    if torch.cuda.is_available():
        x_train = torch.FloatTensor(x_train).cuda()
        # y = torch.LongTensor(y)
        y_train = torch.FloatTensor(y_train).cuda()
    else:
        x_train = torch.FloatTensor(x_train)
        # y = torch.LongTensor(y)
        y_train = torch.FloatTensor(y_train)
    x_train, y_train = Variable(x_train), Variable(y_train)

    '''read the test set'''
    data_test = pd.read_csv(
        './Data/4seasonsFoldnext1time/test_fold%s.csv' % kfold)  # this is the path of your test set.



    data_test = data_test.dropna()
    x_test = data_test[[
        'Alts', 'Azis', 'Evg', 'Evd', 'Evgn', 'Evge', 'Evgs', 'Evgw', 'Lvz', 'Rh', 'Wd', 'Ws', 'Dbt', 'Cvf', 'Cef',
        'Ees',
        'Ees_1time', 'Ees_2time', 'Ees_3time', 'Ees_30time',
        'Ees_90time'
    ]]    # these should be replaced by your real input features' names.


    y_test = data_test[['Ees_nexttime']]  # this should be replaced by your real output feature' name.


    '''normalization'''
    x_test = x_test.values
    x_test = x_test.astype('float32')
    scaler = MinMaxScaler(feature_range=(0, 1))
    x_test = scaler.fit_transform(x_test)
    y_test = y_test.values
    y_test = y_test.astype('float32')
    scaler = MinMaxScaler(feature_range=(0, 1))
    y_test = scaler.fit_transform(y_test)

    if torch.cuda.is_available():
        x_test = torch.FloatTensor(x_test).cuda()
        y_test = torch.FloatTensor(y_test).cuda()
    else:
        x_test = torch.FloatTensor(x_test)
        y_test = torch.FloatTensor(y_test)

    x_test, y_test = Variable(x_test), Variable(y_test)

    train_start = 0
    train_end = 100
    Train_end=train_end
    val_start = train_end
    val_end = val_start + 80
    Val_end = val_end
    epoch_num = val_end
    len_train = len(x_train)
    # epochs = int(len_train / val_end)
    epochs = int(len_train / train_end)-1
    epoch_print = 1
    Epochs, Loss, Val_loss, Loss2, Val_loss2 = [], [], [], [], []
    val_loss_break_num=0
    time_start = time.time()

    for epoch in range(epochs):
        optimizer = torch.optim.SGD(model.parameters(), lr=lr)
        output = model(x_train[train_start:train_end])
        loss = criterion(output, y_train[train_start:train_end])
        loss2 = criterion2(output, y_train[train_start:train_end])
        print_loss = loss2.item()
        optimizer.zero_grad()
        loss2.backward()  # MAE is used
        optimizer.step()
        output_val = model(x_train[val_start:val_end])
        val_loss = criterion(output_val, y_train[val_start:val_end])  # MSE
        val_loss2 = criterion2(output_val, y_train[val_start:val_end])  # MAE
        epoch = epoch + 1
        train_start = train_start + Train_end
        train_end = train_end + Train_end
        val_start = val_start + Train_end
        val_end = val_end + Train_end

        if epoch == epoch_print:
            epoch_print = epoch_print + 10
        else:
            pass
        print('epoch%s ' % epoch, 'loss:%s' % loss.item())

        if val_loss < val_loss_break:
            print(val_loss)
            val_loss_break_num = val_loss_break_num+1
            if val_loss_break_num==10:  #
                print('-------val_loss_break_num==10---------')
                break
        else:
            val_loss_break_num=0

    time_end = time.time()
    traintimecost = (time_end - time_start)
    Traintimecosts=[]
    Traintimecosts.append(traintimecost)
    Traintimecosts = pd.DataFrame(Traintimecosts, columns=['Traintimecosts'])
    Traintimecosts.to_csv('./result_and_score_seasons/KFold/Traintimecost_Fold%s.csv' % kfold)

    model.eval()

    torch.save(model,
               './result_and_score_seasons/KFold/model_Fold%s.pkl' % kfold)

    model_reload = torch.load(
        './result_and_score_seasons/KFold/model_Fold%s.pkl' % kfold)


    print('--------x_test-----------', x_test)
    predict = model_reload(x_test)
    loss = criterion(predict, y_test)
    test_loss = loss.item()
    print('test_loss is：%s' % test_loss)
    if torch.cuda.is_available():
        y_test = y_test.cpu().numpy()  #
    else:
        y_test = y_test.data.cpu().numpy()  #


    if torch.cuda.is_available():
        predict = predict.data.cpu().numpy()  #
    else:
        predict = predict.data.cpu().numpy()  # 用
    # print('predict=',predict)


    # 数据反归一化 inverse transform
    test_y_np2 = scaler.inverse_transform(y_test)
    # 数据反归一化 inverse transform
    predict_test_y_np2 = scaler.inverse_transform(predict)

    output_dimension = 1  #
    y_test_np2 = y_test.reshape(len(y_test), output_dimension)
    predict_test_y_np2 = predict_test_y_np2.reshape(len(predict_test_y_np2),
                                                    output_dimension)


    '''save them'''
    test_y_np2 = pd.DataFrame(test_y_np2, columns=['test_observed'])
    predict_test_y_np2 = pd.DataFrame(predict_test_y_np2, columns=['test_predicted'])
    print(test_y_np2)
    print(predict_test_y_np2)

    df_merge = pd.merge(test_y_np2, predict_test_y_np2, left_index=True, right_index=True, how='outer')

    df_merge.to_csv(
        './result_and_score_seasons/KFold/test_predict_result_Fold%s.csv' % (kfold),
        index=False)

    print('Fold%s finish'%(kfold))

    df_merge = pd.read_csv(
        './result_and_score_seasons/KFold/test_predict_result_Fold%s.csv' %(kfold))

    print('----------------------------------------metrics---------------------------------------')
    RMSEs, MAEs, CV_RMSEs, squaredRs = [],[],[],[]
    data = df_merge
    target = data.iloc[:, 0]
    prediction = data.iloc[:, 1]

    error = []
    for i in range(len(target)):
        error.append(target[i] - prediction[i])

    squaredError = []
    absError = []
    for val in error:
        squaredError.append(val * val)  # target-prediction之差平方
        absError.append(abs(val))  # 误差绝对值

    MSE = sum(squaredError) / len(squaredError)
    RMSE = sqrt(sum(squaredError) / len(squaredError))
    CV_RMSE = sqrt(sum(squaredError)/(len(target)-1))/(sum(target)/ len(target)) # CV-RMSE

    target = target.values
    prediction = prediction.values

    squaredR = (len(target)*((np.dot(target, prediction)))-sum(target)*sum(prediction))**2 /( (len(prediction)*sum(np.square(prediction))-sum(prediction)**2) * (len(target)*sum(np.square(target))-sum(target)**2) )
    MAE = sum(absError) / len(absError)


    RMSEs.append(RMSE)
    MAEs.append(MAE)
    CV_RMSEs.append(CV_RMSE)
    squaredRs.append(squaredR)

    RMSEs = pd.DataFrame(RMSEs, columns=['RMSE'])
    MAEs = pd.DataFrame(MAEs, columns=['MAE'])
    CV_RMSEs = pd.DataFrame(CV_RMSEs, columns=['CV_RMSE'])
    squaredRs = pd.DataFrame(squaredRs, columns=['squaredR'])

    df_merge = pd.merge(RMSEs, MAEs, left_index=True, right_index=True, how='outer')
    df_merge = pd.merge(df_merge, CV_RMSEs, left_index=True, right_index=True, how='outer')
    df_merge = pd.merge(df_merge, squaredRs, left_index=True, right_index=True, how='outer')
    print(df_merge)

    df_merge.to_csv(
        './result_and_score_seasons/KFold/scores_Fold%s.csv' % ( kfold),
        index=False)
    print('------------Fold%s finish-------------' % kfold)

    if kfold == 1:
        df_merge.to_csv(
            './result_and_score_seasons/KFold/scores_Fold_all.csv',
            index=False)
    else:
        df_merge.to_csv(
            './result_and_score_seasons/KFold/scores_Fold_all.csv',
            mode='a', index=False, header=False)


